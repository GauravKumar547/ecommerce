package models;

public enum State {
    ACTIVE,
    INACTIVE
}
