package models;


public enum Role {
    ADMIN,
    USER,
    SELLER
}
